const tncEN = /*html*/ `

<li> This promotion is applicable to the 240 first new M88 Mansion players from 1 September 2023 00:20:00 to 30 September 2023 23:59:00 (GMT+8). <br/>
   The bonus can only be claimed every Friday to Monday of the current month, from 20:00:00 to 02:00:00 (GMT+8). </li>
<li> New Players are eligible to receive Freebet Bonus MYR 28 with 15X rollover in LIVESPINS. </li>
<li> The bonus will be issued in LIVESPINS upon verification of a successful registration. </li>
<li> The Bonus amount must be rolled over 15X in LIVESPINS prior to the withdrawal of winnings. </li>
<li> The bonus rollover must be fulfilled within 30 days to prevent forfeiture of the bonus and winning amount.  </li>
<li> Only LIVESPINS games will count towards the rollover contribution except for all table games, scratch cards, video poker, and arcade games. Click <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.en-US" target="_blank">here</a> to see Included and Excluded game list. </li>
<li> If a player made a minimum deposit of MYR 50 and above they will be eligible for an additional MYR 30 Freebet in Casino Slots (Pragmatic Play) with 3X RO. 
<li>  Withdrawal will only be processed once the minimum deposit is done.  </li>
<li> The bonus cannot be used in conjunction with other M88 Mansion promotions. </li>
<li> Each bonus can only be claimed 1x during the promotion period. </li>
<li> Withdrawals will not be processed if the player still has an active rollover. Please contact Customer Service to arrange for a waiver of the rollover requirement. </li>
<li> M88 Mansion reserves the right to change, update, modify, or cancel this promotion anytime. </li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.en-US">General Terms & Conditions of Promotions apply</a>. </li>


`;
const tncIN = /*html*/ `

<li> This promotion is applicable to the first 200 new M88 Mansion players from 11 September 2023 00:00:00 to 08 October 2023 23:59:00 (GMT+8). </li>
<li> New Players are eligible to receive the 150% bonus up to INR 3,400 with 10X rollover in SPORTS </li>
<li> The bonus will be issued in SPORTS upon verification of successful minimum deposit of INR 500. </li>
<li> The Deposit + Bonus amount must be rolled over 10x in SPORS prior to the withdrawal of winnings. </li>
<li> The bonus rollover must be fulfilled within 7 days to prevent forfeiture of the bonus and winning amount.  </li>
<li> All tie/draw/refund/declined/void/cancelled bets, and bets at decimal odds below 1.50 (Malay odds 0.50; HK odds 0.50; Indo Odds -2.00) will be not included in the calculation for turnover &/or rollover requirement (when applicable). </li>
<li> The bonus cannot be used in conjunction with other M88 Mansion promotions. </li>
<li> Each bonus can only be claimed 1x during the promotion period. </li>
<li> Maximum withdrawal is up to INR 3400. </li>
<li> Withdrawals will not be processed if the player still has an active rollover. Please contact Customer Service to arrange for a waiver of the rollover requirement. </li>
<li> M88 Mansion reserves the right to change, update, modify, or cancel this promotion anytime. </li>
<li> AdvantPlay reserves the right to amend, suspend or cancel the promotion at any time. </li>

`;
const tncID = /*html*/ `

<li> Promosi ini berlaku untuk member baru M88 Mansion di tanggal 1 Februari 00:00:00 hingga 29 Februari 2024 23:59:00 (GMT+8). </li>
<li> Member baru harus melakukan deposit pertama minimal IDR 150 </li>
<li> Member baru perlu klik Opt-in untuk mengikuti promosi ini. </li>
<li> Member baru berhak mendapatkan Bonus Extra IDR 48 di game Lotre dengan 5x Rolllover dan akan dikreditkan Pada hari Senin di awal pekan.

    <div class="table--parent">
        <table>
            <thead>
                <tr>
                    <th>PERMAINAN</th>
                    <th>TIPE BONUS</th>
                    <th>BONUS %</th>
                    <th>MINIMAL DEPO PERTAMA</th>
                    <th>MAKSIMAL BONUS</th>
                    <th>ROLLOVER (DEPOSIT + BONUS)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Lottery</td>
                    <td>Bonus Freebet</td>
                    <td>-</td>
                    <td>IDR 150</td>
                    <td>IDR 48</td>
                    <td>1x RO</td>
                </tr>
            </tbody>
        </table>
    </div>

</li>
<li> Rollover bonus freebet harus dipenuhi dalam waktu 7 hari untuk mencegah pembatalan bonus dan jumlah kemenangan. </li>
<li> Bonus tidak dapat digunakan bersamaan dengan promosi M88 Mansion lainnya kecuali Welcome Bonus. </li>
<li> Bonus hanya dapat diklaim 1x selama periode promosi. </li>
<li> Withdraw tidak akan diproses jika pemain masih aktif melakukan rollover. Silakan hubungi Layanan Pelanggan untuk mengatur pengabaian persyaratan rollover. </li>
<li> M88 Mansion berhak mengubah, memperbarui, memodifikasi, atau membatalkan promosi ini kapan saja. </li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.id-ID"> Syarat & Ketentuan Umum Promosi berlaku</a>. </li>

`;
const tncTH = /*html*/ `
<li> โปรโมชั่นนี้ใช้ได้กับสมาชิกใหม่ M88 Mansion 800 ท่านแรก ที่ทำการสมัครตั้งแต่วันที่ 26 กุมภาพันธ์ 2567 00:00:00 น. เป็นต้นไป </li>
<li>สมาชิกใหม่มีสิทธ์เลือกรับโบนัสหากทำรายการฝากขั้นต่ำตามที่กำหนด ดังนี้

    <ol>
        <li> เมื่อทำการฝากขั้นต่ำ 100 บาท รับโบนัส 500 บาท ที่คาสิโนสล็อตหรือคาสิโนสด</li>
        <li> เมื่อทำการฝากขั้นต่ำ 200 บาท รับโบนัส 888 บาท ที่คาสิโนสล็อตหรือคาสิโนสด</li>
    </ol>

    <div class="table--parent">
        <table>
            <thead>
                <tr>
                    <th>ยอดฝากขั้นต่ำ</th>
                    <th>โบนัส</th>
                    <th>ผลิตภัณฑ์</th>
                    <th>ถอนขั้นต่ำ</th>
                    <th>ถอนสูงสุด</th>
                    <th>ยอดเทิร์น (เงินฝาก+โบนัส)</th>
                    <th>สำหรับผู้สมัคร</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td rowspan="2">100 บาท</td>
                    <td rowspan="2">500 บาท</td>
                    <td >คาสิโนสล็อต</td>
                    <td rowspan="2">250 บาท</td>
                    <td rowspan="2">1,000 บาท</td>
                    <td rowspan="2">10 เท่า</td>
                    <td rowspan="4">800</td>
                </tr>
                <tr>
                    <td>คาสิโนสด</td>
                </tr>
                <tr>
                    <td rowspan="2">200 บาท</td>
                    <td rowspan="2">888 บาท</td>
                    <td >คาสิโนสล็อต</td>
                    <td rowspan="2">500 บาท</td>
                    <td rowspan="2">2,500 บาท</td>
                    <td rowspan="2">12 เท่า</td>
                </tr>
                <tr>
                    <td>คาสิโนสด</td>
                </tr>
            </tbody>
        </table>
    </div>

</li>

<li> โบนัส+เงินฝาก มียอดเดิมพันหมุนเวียน 10 เท่า สำหรับโบนัส 500 บาท 
หรือยอดเดิมพันหมุนเวียน 12 เท่า สำหรับโบนัส 888 บาท ในคาสิโนสล็อตหรือคาสิโนสด จึงจะสามารถทำการถอนเงินได้ </li>
<li> สำหรับโบนัส 500 บาท การถอนขั้นต่ำเริ่มที่ 250 บาท สามารถถอนได้สูงสุด 1,000 บาท 
และสำหรับโบนัส 888 บาท การถอนขั้นต่ำเริ่มที่ 500 บาท สามารถถอนได้สูงสุด 2,500 บาท </li>
<li> โบนัสจะต้องทำยอดเดิมพันหมุนเวียนให้สำเร็จภายใน 7 วันเพื่อป้องกันการริบโบนัสและจำนวนเงินที่ชนะคืน </li>
<li> ไม่สามารถใช้โบนัสร่วมกับโปรโมชั่นอื่นๆ ของ M88 Mansion ได้ นอกจากที่ระบุไว้ </li>
<li> สำหรับคาสิโน
เฉพาะเกมคาสิโนสล็อตเท่านั้นที่จะนับรวมในยอดเดิมพันหมุนเวียน ยกเว้นเกมโต๊ะ scratch cards วิดีโอโป๊กเกอร์ และเกมอาร์เคดทั้งหมด คลิกที่นี่ เพื่อดูรายชื่อเกมที่เข้าร่วมและไม่ร่วม

สำหรับคาสิโนสด
เกมคาสิโนสดทั้งหมดจะนับรวมเป็นยอดเดิมพันหมุนเวียน ยกเว้น คาสิโนสดแบล็คแจ๊ค เดิมพันที่โมฆะ และการเดิมพันทั้งสองฝั่ง
</li>
<li> จะไม่สามารถดำเนินการถอนเงินได้ หากยอดหมุนเวียนยังไม่ผ่านเงื่อนไขที่กำหนด สมาชิกสามารถติดต่อฝ่ายประชาสัมพันธ์ลูกค้า เพื่อแจ้งดำเนินการยกเลิกยอดหมุนเวียนเดิมพันที่กำหนดได้ </li>
<li> โบนัสนี้สามารถขอรับได้เพียง 1 ครั้งในช่วงระยะเวลาของโปรโมชั่น </li>
<li> M88 Mansion ขอสงวนสิทธิ์ในการเปลี่ยนแปลงปรับปรุงแก้ไขหรือยกเลิกโปรโมชั่นนี้ได้ตลอดเวลา </li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.th-TH"> ข้อตกลงทั่วไปและเงื่อนไขการใช้งานโปรโมชั่น </a> </li>
`;
const tncVN = /*html*/ `

<li> Khuyến mãi áp dụng cho 300 thành viên mới M88 Mansion từ ngày 08/01/2024 lúc 00:00:00 đến ngày 10/02/2024 lúc 23:59:00 (GMT+8). </li>
<li> Thành viên mới hợp lệ chọn một (1) trong 188% Thưởng Chào Mừng lên đến 988 VND HOẶC 348 VND Freebet tại THỂ THAO (CÁC TRẬN AFC). </li>
<li> Thưởng sẽ được cập nhật sau khi xác nhận khoản gửi tiền tối thiểu là 200 VND. </li>
<li> Tiền gửi và thưởng cần trải qua 8x vòng cược tại THỂ THAO (CÁC TRẬN AFC) trước khi có thể rút tiền thắng.  </li>
<li> Thành viên có cược thua đầu tiên tối thiểu là 200 VND sẽ hợp lệ được nhận thêm thưởng hoàn tiền 68% lên đến 548 VND tại THỂ THAO (TRẬN ĐẤU AFC) với 6x vòng cược.  </li>
<li> Số vòng cược cần hoàn tất trong vòng 7 ngày để tránh bị thu hồi tiền thưởng và tiền thắng. </li>
<li> Tất cả cược hòa/từ chối /vô hiệu/bị hủy và loại cược DEC có tỷ lệ dưới 1.50 (Malay tỷ lệ 0.50; HK tỷ lệ 0.50; Indo tỷ lệ -2.00) sẽ không tính vào doanh thu và/hoặc tiền tái đặt cược. </li>
<li> Khuyến mãi không thể kết hợp với các khuyến mãi khác trên trang M88 Mansion.  </li>
<li> Tiền thưởng chỉ được nhận 01 lần trong thời gian diễn ra khuyến mãi. </li>
<li> Thành viên không thể rút tiền nếu chưa hoàn tất yêu cầu vòng cược. Vui lòng liên hệ bộ phận Chăm sóc Khách Hàng để được hỗ trợ. </li>
<li> M88 Mansion có quyền thay đổi, cập nhật, điều chỉnh hoặc hủy khuyến mãi bất cứ lúc nào. </li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.vi-VN"> Các quy định chung của chương trình khuyến mãi được áp dụng</a>. </li>
`;
const tncCN = /*html*/ `

<li> 活动期间：2023年7月1日至7月31，邀请前240位新注册的明陞M88玩家。 <br/> 
	奖金只能在当月每周五至周一的20:00:00至02:00:00（北京时间）领取。 </li>
<li> 新玩家可于《LIVESPINS》游戏中获得138人民币免费投注礼金（15倍流水）。 </li>
<li> 玩家达成注册后，即可于《LIVESPINS》获得免费投注礼金。 </li>
<li> 提款前存款加礼金，必须在《LIVESPINS》游戏中达成15倍流水。 </li>
<li> 礼金自收到后30天内有效。请在有效期内达到指定投注金额，逾期系统将自动取消赠金及中奖金额。 </li>
<li> 本活动流水计算仅累计《LIVESPINS》游戏，其余游戏将无法累计。<a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.zh-CN">查看包含和排除游戏列表。</a> </li>
<li> 玩家完成最低100人民币首存后，可获得于《Pragmatic Play 老虎机》加码50人民币免费投注（3倍流水） </li>
<li> 完成最低存款额后，即可申请提款。 </li>
<li> 本活动不能与明陞M88其他活动同时进行。 </li>
<li> 活动期间内，每位玩家仅可领取一次活动礼金。 </li>
<li> 如果您的账户仍有未完成的有效流水要求，您将无法提款。请联系在线客服办理撤除/取消/豁免流水要求即可。 </li>
<li> 明陞M88保留随时更改、更新、修改或取消此促销活动的权利。 </li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.zh-CN"> 一般条款及规则应用于此优惠。</a> </li>

`;
const tncMYCN = /*html*/ `

<li> 活动日期：2023年9月1日至9月30日，期间内新注册的明陞M88玩家。 <br/>
	奖金只能在当月每周五至周一的20:00:00至02:00:00（北京时间）领取。 </li>
<li> 新玩家可于《LIVESPINS》游戏中获得28马币免费投注礼金（15倍流水）。 </li>
<li> 玩家达成注册后，即可于《LIVESPINS》获得免费投注礼金。 </li>
<li> 提款前存款加礼金，必须在《LIVESPINS》游戏中达成15倍流水。 </li>
<li> 礼金自收到后30天内有效。请在有效期内达到指定投注金额，逾期系统将自动取消赠金及中奖金额。 </li>
<li> 本活动流水计算仅累计《LIVESPINS》游戏，其余游戏将无法累计。<a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.zh-CN">查看包含和排除游戏列表<a/>。</li>
<li> 玩家完成最低50马币首存后，可获得于《Pragmatic Play 老虎机》加码30马币免费投注（3倍流水） </li>
<li> 完成最低存款额后，即可申请提款。 </li>
<li> 本活动不能与明陞M88其他活动同时进行。 </li>
<li> 活动期间内，每位玩家仅可领取一次活动礼金。 </li>
<li> 如果您的账户仍有未完成的有效流水要求，您将无法提款。请联系在线客服办理撤除/取消/豁免流水要求即可。 </li>
<li> 明陞M88保留随时更改、更新、修改或取消此促销活动的权利。 </li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.zh-CN"> 一般条款及规则应用于此优惠。</a> </li>

`;
const tncKRW = /*html*/ `

<li> 본 프로모션은 2024년 1월 8일 01:00부터 2024년 2월 10일까지 M88 맨션 신규 회원 300명을 선착순으로 진행됩니다. </li>
<li> 신규 회원은 스포츠 아시안컵 경기에서 이용 가능한 최대 KRW 38,888까지 주어지는 188% 웰컴 보너스 또는  KRW 10,000 프리벳 보너스를 수령할 수 있습니다. </li>
<li> 본 보너스는 최소 입금 KRW 10,000을 입금한 M88 신규 회원에게만 지급됩니다. </li>
<li> 출금 전 입금 금액과 보너스 금액은 스포츠 아시안컵 경기에서 8배의 롤오버를 충족해야 합니다. </li>
<li> 최대 KRW 24,888이 주어지는 추가 68% 캐시백 보너스에는 스포츠 아시안컵 경기에서 6배의 롤오버가 적용되며, 신규 회원이 캐시백 보너스를 수령하기 위해서는 첫 베팅에서 최소 KRW 10,000 이상의 베팅을 낙첨해야 합니다. </li>
<li> 본 보너스는 수령 후 7일 이내 롤오버를 충족해야 하며, 그러지 않을 시 보너스와 보너스로 발생된 상금은 몰수됩니다. </li>
<li> 모든 동점/무승부/환불/거절/무효/취소된 베팅 및 1.50 미만 소수점 배당률(말레이 0.5, 홍콩 0.5, 인도-2)의 베팅은 턴오버, 롤오버에 포함되지 않습니다. </li>
<li> 본 보너스는 달리 명시되지 않는 한 M88 맨션의 타 보너스와 중복 신청이 불가능합니다. </li>
<li> 본 보너스는 프로모션 기간 동안 최대 1회만 수령할 수 있습니다. </li>
<li> 롤오버가 충족되지 않으면 출금은 불가능합니다. 더 자세한 문의 사항은 라이브챗으로 문의하시기 바랍니다. </li>
<li> 당사는 언제든 이 프로모션을 변경 혹은 취소할 수 있습니다. </li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.ko-KR"> 일반 이용약관이 적용됩니다</a>. </li>

`;
const tncJPY = /*html*/ `

<h3 class="raf-header"> M88マンションのお友だち紹介ボーナスとは何ですか? </h3>
<p class="raf-description">仲間が多ければ多いほど楽しい! お友だちを誘って、M88で楽しい時間を過ごしませんか。 お友達に招待リンクを送信してください。お友だちがサインアップしてアカウントに入金してプレイをすると、あなたもお友だちも最大$20 のボーナスを獲得できます!</p>

    <div class="table--parent">
        <table>
            <thead>
                <tr>
                    <th>通貨</th>
                    <th>お友だちの最低入金額</th>
                    <th>お友だちのボーナス</th>
                    <th>紹介者のボーナス</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>USD</td>
                    <td>USD 10</td>
                    <td>USD 10</td>
                    <td>USD 10</td>
                </tr>
            </tbody>
        </table>
    </div>



<h3 class="raf-description">どうやってM88 にお友だちを紹介するの?</h3>
    <div class="refer-steps">
        <p>1. M88のアカウントにログインしてください。 </p>
        <p>2. お友だちのEメールアドレスを入力して送信してください。お友達は何人でも紹介できます。</p>
        <p>3. 紹介者、友だち双方がお友だち紹介ボーナスを獲得するには、紹介したお友だちは受け取ったメール内のリンクをクリックして30日以内にアカウント登録する必要があります。また、お友だちはこれまでにM88でアカウントを登録していないことも条件です。</p>
        <p>4. お友だちがお友だちボーナスを受け取るための必要条件を満たした後、カスタマーサポートに連絡をとり、ボーナスを請求してください。</p>
    </div>



<h3 class="raf-header">利用条件 - お友だち紹介</h3>
<li> このプロモーションはアクティブなすべてのM88メンバーが対象です。アクティブメンバーに認定されるには、アカウント登録後、最低でも1回以上の決済された賭けを行っていることが必要です。</li>
<li>紹介者がお友だち紹介ボーナスを獲得するには、お友だちが最低USD10の入金を登録後 30日以内に行う必要があります。</li>
<li><a href="https://www.m88.com/referafriend" class="tc--link" target="_blank">お友だちの紹介者数は無制限です。</a></li>
<li>紹介されたお友だちは入金を行った後に USD10のお友だち紹介ボーナスを獲得できます。</li>
<li> 紹介者は、お友だちが 「お友だち紹介プログラム」に必要な最低金額USD10以上を入金することを条件に、紹介 1件につきUSD10を獲得できます。</li>
<li>お友だち紹介ボーナスは、選択されたウォレット (例、スポーツ、ライブゲームなど) のロールオーバー条件が適用されます。14日間以内に条件を達成することにより出金が可能となります。こちらをクリックして対象ゲーム、除外ゲームを確認してください。</li>
        <div class="table--parent">
            <table>
                <thead>
                    <tr>
                        <th>プロダクト</th>
                        <th>ロールオーバー (入金 + ボーナス)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Mスポーツ</td>
                        <td>8倍</td>
                    </tr>
                    <tr>
                        <td>BTi</td>
                        <td>8倍</td>
                    </tr>
                    <tr>
                        <td>eスポーツ</td>
                        <td>8倍</td>
                    </tr>
                    <tr>
                        <td>キノ&ロト</td>
                        <td>8倍</td>
                    </tr>
                    <tr>
                        <td>カジノスロット</td>
                        <td>18倍</td>
                    </tr>
                    <tr>
                        <td>ライブカジノ</td>
                        <td>28倍</td>
                    </tr>
                </tbody>
            </table>
        </div>
</li>
<li> 新規登録メンバーは初回入金時にお友だち紹介ボーナスを受け取ることができます。</li>
<li> お友だち（新規メンバー）でお友だち紹介ボーナスを受け取っている場合、お友だちボーナスからの勝利金を出金するためには最低でもUSD10の入金をする必要があります。</li>
<li> 紹介者は、お友だちボーナスからの勝利金を出金するためには最低でもUSD10の入金をする必要があります。</li>
<li> お友達紹介ボーナスの引き出しは、承認制となっております。もし不審な活動を行う紹介者や被紹介者が居た場合は、対象アカウントは、上限がUSD 200になる場合があります。</li>
<li> 「お友だち紹介プログラム」の対象は、単一アカウント保有メンバーであること、システム上で不正なタグが付けされていないこと、紹介者とお友だちがディバイス、IPアドレスを共有していない、同一世帯ではないことではないことが条件となります。</li>
<li> M88マンションは、いつでもプロモーションを変更、更新、修正、中止する権利を有します。</li>
<li> プロモーションの一般利用規約が適用されます。</li>

`;
